# Portfólio João Túlio

Este projeto foi criado com CRA (Create React App).

Este é meu site para me apresentar, aqui coloco minhas habilidades, portfólio, e formas de contato.


## Tecnologias usadas:
- React
- Typescript
- Styled Components

